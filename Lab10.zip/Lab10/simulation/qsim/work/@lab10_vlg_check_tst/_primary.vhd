library verilog;
use verilog.vl_types.all;
entity Lab10_vlg_check_tst is
    port(
        Cor             : in     vl_logic_vector(2 downto 0);
        sampler_rx      : in     vl_logic
    );
end Lab10_vlg_check_tst;
