library verilog;
use verilog.vl_types.all;
entity Reg8_vlg_sample_tst is
    port(
        carga           : in     vl_logic;
        Clk             : in     vl_logic;
        \In\            : in     vl_logic_vector(7 downto 0);
        rst_async       : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end Reg8_vlg_sample_tst;
