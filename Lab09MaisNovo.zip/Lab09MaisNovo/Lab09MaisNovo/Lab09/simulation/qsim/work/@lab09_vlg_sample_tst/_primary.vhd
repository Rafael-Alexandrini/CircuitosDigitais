library verilog;
use verilog.vl_types.all;
entity Lab09_vlg_sample_tst is
    port(
        clk             : in     vl_logic;
        FlagN           : in     vl_logic;
        FlagZ           : in     vl_logic;
        opcode          : in     vl_logic_vector(3 downto 0);
        rst_async       : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end Lab09_vlg_sample_tst;
