library verilog;
use verilog.vl_types.all;
entity Codificador is
    port(
        selULA          : out    vl_logic_vector(2 downto 0);
        ULA_NOT         : in     vl_logic;
        ULA_OR          : in     vl_logic;
        ULA_AND         : in     vl_logic;
        ULA_ADD         : in     vl_logic;
        ULA_Y           : in     vl_logic
    );
end Codificador;
