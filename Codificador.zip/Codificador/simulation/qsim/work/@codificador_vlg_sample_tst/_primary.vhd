library verilog;
use verilog.vl_types.all;
entity Codificador_vlg_sample_tst is
    port(
        ULA_ADD         : in     vl_logic;
        ULA_AND         : in     vl_logic;
        ULA_NOT         : in     vl_logic;
        ULA_OR          : in     vl_logic;
        ULA_Y           : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end Codificador_vlg_sample_tst;
