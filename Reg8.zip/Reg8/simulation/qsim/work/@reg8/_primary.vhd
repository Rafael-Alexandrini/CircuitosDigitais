library verilog;
use verilog.vl_types.all;
entity Reg8 is
    port(
        \Out\           : out    vl_logic_vector(7 downto 0);
        \In\            : in     vl_logic_vector(7 downto 0);
        carga           : in     vl_logic;
        rst_async       : in     vl_logic;
        Clk             : in     vl_logic
    );
end Reg8;
