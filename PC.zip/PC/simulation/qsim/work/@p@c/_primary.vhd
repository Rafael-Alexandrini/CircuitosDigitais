library verilog;
use verilog.vl_types.all;
entity PC is
    port(
        PCout           : out    vl_logic_vector(7 downto 0);
        PCin            : in     vl_logic_vector(7 downto 0);
        cargaPC         : in     vl_logic;
        incrementaPC    : in     vl_logic;
        rst_async       : in     vl_logic;
        Clk             : in     vl_logic
    );
end PC;
