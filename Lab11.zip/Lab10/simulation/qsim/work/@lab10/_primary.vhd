library verilog;
use verilog.vl_types.all;
entity Lab10 is
    port(
        A               : out    vl_logic;
        Subida          : in     vl_logic;
        Descida         : in     vl_logic;
        Reset           : in     vl_logic;
        Clka            : in     vl_logic;
        S               : out    vl_logic;
        D               : out    vl_logic
    );
end Lab10;
