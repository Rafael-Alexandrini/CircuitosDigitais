library verilog;
use verilog.vl_types.all;
entity Lab08 is
    port(
        SH              : out    vl_logic_vector(6 downto 0);
        CLKi            : in     vl_logic;
        D               : in     vl_logic_vector(7 downto 0);
        Selt            : in     vl_logic_vector(1 downto 0);
        SL              : out    vl_logic_vector(6 downto 0)
    );
end Lab08;
