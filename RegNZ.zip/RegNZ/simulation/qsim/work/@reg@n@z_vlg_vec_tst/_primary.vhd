library verilog;
use verilog.vl_types.all;
entity RegNZ_vlg_vec_tst is
end RegNZ_vlg_vec_tst;
