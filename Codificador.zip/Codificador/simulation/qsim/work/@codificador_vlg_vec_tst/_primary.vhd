library verilog;
use verilog.vl_types.all;
entity Codificador_vlg_vec_tst is
end Codificador_vlg_vec_tst;
