library verilog;
use verilog.vl_types.all;
entity Lab10_vlg_check_tst is
    port(
        g               : in     vl_logic;
        o               : in     vl_logic_vector(4 downto 0);
        r               : in     vl_logic;
        S               : in     vl_logic_vector(3 downto 0);
        y               : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end Lab10_vlg_check_tst;
