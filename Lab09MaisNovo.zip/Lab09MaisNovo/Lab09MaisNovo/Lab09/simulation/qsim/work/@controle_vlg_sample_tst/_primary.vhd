library verilog;
use verilog.vl_types.all;
entity Controle_vlg_sample_tst is
    port(
        ADD             : in     vl_logic;
        \AND\           : in     vl_logic;
        FlagN           : in     vl_logic;
        FlagZ           : in     vl_logic;
        JMP             : in     vl_logic;
        JN              : in     vl_logic;
        JZ              : in     vl_logic;
        LDA             : in     vl_logic;
        NOP             : in     vl_logic;
        \NOT\           : in     vl_logic;
        \OR\            : in     vl_logic;
        t               : in     vl_logic_vector(7 downto 0);
        sampler_tx      : out    vl_logic
    );
end Controle_vlg_sample_tst;
