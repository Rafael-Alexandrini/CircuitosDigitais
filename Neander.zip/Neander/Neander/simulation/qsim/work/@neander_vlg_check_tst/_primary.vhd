library verilog;
use verilog.vl_types.all;
entity Neander_vlg_check_tst is
    port(
        ACDisplay       : in     vl_logic_vector(6 downto 0);
        ACOut           : in     vl_logic_vector(7 downto 0);
        FlagN           : in     vl_logic;
        FlagZ           : in     vl_logic;
        HLT             : in     vl_logic;
        PCDisplay       : in     vl_logic_vector(6 downto 0);
        PCOut           : in     vl_logic_vector(7 downto 0);
        sampler_rx      : in     vl_logic
    );
end Neander_vlg_check_tst;
