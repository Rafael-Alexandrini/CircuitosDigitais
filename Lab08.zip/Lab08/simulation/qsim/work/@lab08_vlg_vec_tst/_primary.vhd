library verilog;
use verilog.vl_types.all;
entity Lab08_vlg_vec_tst is
end Lab08_vlg_vec_tst;
