library verilog;
use verilog.vl_types.all;
entity ADD_vlg_check_tst is
    port(
        ADDOut          : in     vl_logic_vector(7 downto 0);
        sampler_rx      : in     vl_logic
    );
end ADD_vlg_check_tst;
