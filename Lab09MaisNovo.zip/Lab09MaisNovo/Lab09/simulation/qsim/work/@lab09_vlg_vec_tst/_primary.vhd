library verilog;
use verilog.vl_types.all;
entity Lab09_vlg_vec_tst is
end Lab09_vlg_vec_tst;
