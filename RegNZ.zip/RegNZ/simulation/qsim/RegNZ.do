onerror {quit -f}
vlib work
vlog -work work RegNZ.vo
vlog -work work RegNZ.vt
vsim -novopt -c -t 1ps -L cycloneiii_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.RegNZ_vlg_vec_tst
vcd file -direction RegNZ.msim.vcd
vcd add -internal RegNZ_vlg_vec_tst/*
vcd add -internal RegNZ_vlg_vec_tst/i1/*
add wave /*
run -all
