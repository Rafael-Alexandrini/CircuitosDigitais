library verilog;
use verilog.vl_types.all;
entity Lab10_vlg_check_tst is
    port(
        pin_name1       : in     vl_logic;
        pin_name2       : in     vl_logic;
        pin_name3       : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end Lab10_vlg_check_tst;
