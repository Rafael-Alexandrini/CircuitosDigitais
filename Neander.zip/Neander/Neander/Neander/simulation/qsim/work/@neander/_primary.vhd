library verilog;
use verilog.vl_types.all;
entity Neander is
    port(
        FlagN           : out    vl_logic;
        FlagZ           : out    vl_logic;
        Reset           : in     vl_logic;
        clk_in          : in     vl_logic;
        StepUp          : in     vl_logic;
        RunDebugSel     : in     vl_logic;
        HLT             : out    vl_logic;
        ACOut           : out    vl_logic_vector(7 downto 0);
        HACDisplay      : out    vl_logic_vector(6 downto 0);
        HPCDisplay      : out    vl_logic_vector(6 downto 0);
        LACDisplay      : out    vl_logic_vector(6 downto 0);
        LPCDisplay1     : out    vl_logic_vector(6 downto 0);
        PCOut           : out    vl_logic_vector(7 downto 0)
    );
end Neander;
