library verilog;
use verilog.vl_types.all;
entity RunStepSel_vlg_sample_tst is
    port(
        ClkManual       : in     vl_logic;
        ClkNormal       : in     vl_logic;
        RunDebugSel     : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end RunStepSel_vlg_sample_tst;
