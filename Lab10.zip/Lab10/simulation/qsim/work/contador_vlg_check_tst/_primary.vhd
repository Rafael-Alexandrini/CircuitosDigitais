library verilog;
use verilog.vl_types.all;
entity contador_vlg_check_tst is
    port(
        Cout            : in     vl_logic;
        Q               : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end contador_vlg_check_tst;
