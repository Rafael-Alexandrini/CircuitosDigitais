onerror {quit -f}
vlib work
vlog -work work Codificador.vo
vlog -work work Codificador.vt
vsim -novopt -c -t 1ps -L cycloneiv_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.Codificador_vlg_vec_tst
vcd file -direction Codificador.msim.vcd
vcd add -internal Codificador_vlg_vec_tst/*
vcd add -internal Codificador_vlg_vec_tst/i1/*
add wave /*
run -all
