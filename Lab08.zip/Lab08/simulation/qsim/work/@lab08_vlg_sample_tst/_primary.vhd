library verilog;
use verilog.vl_types.all;
entity Lab08_vlg_sample_tst is
    port(
        CLKi            : in     vl_logic;
        D               : in     vl_logic_vector(7 downto 0);
        Selt            : in     vl_logic_vector(1 downto 0);
        sampler_tx      : out    vl_logic
    );
end Lab08_vlg_sample_tst;
