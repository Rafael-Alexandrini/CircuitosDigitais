library verilog;
use verilog.vl_types.all;
entity Lab09 is
    port(
        incrementa_PC   : out    vl_logic;
        FlagN           : in     vl_logic;
        FlagZ           : in     vl_logic;
        opcode          : in     vl_logic_vector(3 downto 0);
        clk             : in     vl_logic;
        rst_async       : in     vl_logic;
        carga_RI        : out    vl_logic;
        sel             : out    vl_logic;
        carga_REM       : out    vl_logic;
        Read            : out    vl_logic;
        UAL_Y           : out    vl_logic;
        UAL_ADD         : out    vl_logic;
        UAL_OR          : out    vl_logic;
        UAL_AND         : out    vl_logic;
        UAL_NOT         : out    vl_logic;
        carga_AC        : out    vl_logic;
        carga_NZ        : out    vl_logic;
        carga_PC        : out    vl_logic;
        goto_t0         : out    vl_logic;
        tres_jmp        : out    vl_logic;
        oito_ops        : out    vl_logic;
        nao_jmp         : out    vl_logic;
        quatro_ops      : out    vl_logic;
        t               : out    vl_logic_vector(7 downto 0)
    );
end Lab09;
