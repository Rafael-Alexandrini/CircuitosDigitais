library verilog;
use verilog.vl_types.all;
entity Lab10_vlg_check_tst is
    port(
        Estado          : in     vl_logic_vector(3 downto 0);
        Q               : in     vl_logic_vector(4 downto 0);
        ResetSignal     : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end Lab10_vlg_check_tst;
