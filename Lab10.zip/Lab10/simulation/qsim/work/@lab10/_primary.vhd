library verilog;
use verilog.vl_types.all;
entity Lab10 is
    port(
        ResetSignal     : out    vl_logic;
        Reset           : in     vl_logic;
        Clk             : in     vl_logic;
        Estado          : out    vl_logic_vector(3 downto 0);
        Q               : out    vl_logic_vector(4 downto 0)
    );
end Lab10;
