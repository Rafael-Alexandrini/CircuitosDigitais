library verilog;
use verilog.vl_types.all;
entity Controle is
    port(
        sel             : out    vl_logic;
        t               : in     vl_logic_vector(7 downto 0);
        qops            : out    vl_logic;
        LDA             : in     vl_logic;
        \OR\            : in     vl_logic;
        \AND\           : in     vl_logic;
        ADD             : in     vl_logic;
        Read            : out    vl_logic;
        oops            : out    vl_logic;
        tjmps           : out    vl_logic;
        JN              : in     vl_logic;
        FlagN           : in     vl_logic;
        JZ              : in     vl_logic;
        FlagZ           : in     vl_logic;
        JMP             : in     vl_logic;
        carga_REM       : out    vl_logic;
        incrementa_PC   : out    vl_logic;
        njmps           : out    vl_logic;
        carga_RI        : out    vl_logic;
        UAL_Y           : out    vl_logic;
        UAL_ADD         : out    vl_logic;
        UAL_OR          : out    vl_logic;
        UAL_AND         : out    vl_logic;
        UAL_NOT         : out    vl_logic;
        \NOT\           : in     vl_logic;
        carga_AC        : out    vl_logic;
        carga_NZ        : out    vl_logic;
        carga_PC        : out    vl_logic;
        goto_t0         : out    vl_logic;
        NOP             : in     vl_logic
    );
end Controle;
