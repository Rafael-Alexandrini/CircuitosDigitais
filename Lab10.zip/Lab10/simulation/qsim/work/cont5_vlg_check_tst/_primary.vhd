library verilog;
use verilog.vl_types.all;
entity cont5_vlg_check_tst is
    port(
        Q               : in     vl_logic_vector(4 downto 0);
        sampler_rx      : in     vl_logic
    );
end cont5_vlg_check_tst;
