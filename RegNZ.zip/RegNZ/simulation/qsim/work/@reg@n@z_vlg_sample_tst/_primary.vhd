library verilog;
use verilog.vl_types.all;
entity RegNZ_vlg_sample_tst is
    port(
        cargaNZ         : in     vl_logic;
        Clk             : in     vl_logic;
        Nin             : in     vl_logic;
        rst_async       : in     vl_logic;
        Zin             : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end RegNZ_vlg_sample_tst;
