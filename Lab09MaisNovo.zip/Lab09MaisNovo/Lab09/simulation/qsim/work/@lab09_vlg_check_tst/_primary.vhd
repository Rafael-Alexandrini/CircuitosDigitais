library verilog;
use verilog.vl_types.all;
entity Lab09_vlg_check_tst is
    port(
        carga_AC        : in     vl_logic;
        carga_NZ        : in     vl_logic;
        carga_PC        : in     vl_logic;
        carga_RDM       : in     vl_logic;
        carga_REM       : in     vl_logic;
        carga_RI        : in     vl_logic;
        goto_t0         : in     vl_logic;
        incrementa_PC   : in     vl_logic;
        Read            : in     vl_logic;
        sel             : in     vl_logic;
        t               : in     vl_logic_vector(7 downto 0);
        UAL_ADD         : in     vl_logic;
        UAL_AND         : in     vl_logic;
        UAL_NOT         : in     vl_logic;
        UAL_OR          : in     vl_logic;
        UAL_Y           : in     vl_logic;
        Write           : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end Lab09_vlg_check_tst;
