library verilog;
use verilog.vl_types.all;
entity cont5 is
    port(
        Q               : out    vl_logic_vector(4 downto 0);
        Clk             : in     vl_logic;
        Reset           : in     vl_logic
    );
end cont5;
