-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "06/05/2025 11:12:06"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	Lab08 IS
    PORT (
	SH : OUT std_logic_vector(6 DOWNTO 0);
	CLKi : IN std_logic;
	D : IN std_logic_vector(7 DOWNTO 0);
	Selt : IN std_logic_vector(1 DOWNTO 0);
	SL : OUT std_logic_vector(6 DOWNTO 0)
	);
END Lab08;

-- Design Ports Information
-- SH[6]	=>  Location: PIN_A15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SH[5]	=>  Location: PIN_E14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SH[4]	=>  Location: PIN_B14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SH[3]	=>  Location: PIN_A14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SH[2]	=>  Location: PIN_C13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SH[1]	=>  Location: PIN_B13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SH[0]	=>  Location: PIN_A13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SL[6]	=>  Location: PIN_F13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SL[5]	=>  Location: PIN_F12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SL[4]	=>  Location: PIN_G12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SL[3]	=>  Location: PIN_H13,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SL[2]	=>  Location: PIN_H12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SL[1]	=>  Location: PIN_F11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- SL[0]	=>  Location: PIN_E11,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[6]	=>  Location: PIN_H7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Selt[1]	=>  Location: PIN_D2,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Selt[0]	=>  Location: PIN_E4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- CLKi	=>  Location: PIN_G21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[4]	=>  Location: PIN_G5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[5]	=>  Location: PIN_J7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[7]	=>  Location: PIN_E3,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[2]	=>  Location: PIN_H6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[0]	=>  Location: PIN_J6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[1]	=>  Location: PIN_H5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- D[3]	=>  Location: PIN_G4,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF Lab08 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_SH : std_logic_vector(6 DOWNTO 0);
SIGNAL ww_CLKi : std_logic;
SIGNAL ww_D : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_Selt : std_logic_vector(1 DOWNTO 0);
SIGNAL ww_SL : std_logic_vector(6 DOWNTO 0);
SIGNAL \CLKi~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \SH[6]~output_o\ : std_logic;
SIGNAL \SH[5]~output_o\ : std_logic;
SIGNAL \SH[4]~output_o\ : std_logic;
SIGNAL \SH[3]~output_o\ : std_logic;
SIGNAL \SH[2]~output_o\ : std_logic;
SIGNAL \SH[1]~output_o\ : std_logic;
SIGNAL \SH[0]~output_o\ : std_logic;
SIGNAL \SL[6]~output_o\ : std_logic;
SIGNAL \SL[5]~output_o\ : std_logic;
SIGNAL \SL[4]~output_o\ : std_logic;
SIGNAL \SL[3]~output_o\ : std_logic;
SIGNAL \SL[2]~output_o\ : std_logic;
SIGNAL \SL[1]~output_o\ : std_logic;
SIGNAL \SL[0]~output_o\ : std_logic;
SIGNAL \CLKi~input_o\ : std_logic;
SIGNAL \CLKi~inputclkctrl_outclk\ : std_logic;
SIGNAL \Selt[1]~input_o\ : std_logic;
SIGNAL \D[6]~input_o\ : std_logic;
SIGNAL \Selt[0]~input_o\ : std_logic;
SIGNAL \D[5]~input_o\ : std_logic;
SIGNAL \insto|inst5|inst2|inst1~0_combout\ : std_logic;
SIGNAL \D[4]~input_o\ : std_logic;
SIGNAL \D[3]~input_o\ : std_logic;
SIGNAL \D[0]~input_o\ : std_logic;
SIGNAL \insto|inst|inst1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst4|inst3~0_combout\ : std_logic;
SIGNAL \insto|inst|inst3~q\ : std_logic;
SIGNAL \D[1]~input_o\ : std_logic;
SIGNAL \insto|inst1|inst1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst1|inst1|inst1~1_combout\ : std_logic;
SIGNAL \insto|inst1|inst3~q\ : std_logic;
SIGNAL \D[2]~input_o\ : std_logic;
SIGNAL \insto|inst2|inst2|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst2|inst1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst2|inst3~q\ : std_logic;
SIGNAL \insto|inst2|inst3mx1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst3|inst2|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst3|inst1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst3|inst3~q\ : std_logic;
SIGNAL \insto|inst4|inst2|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst4|inst1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst4|inst3~q\ : std_logic;
SIGNAL \insto|inst4|inst3mx1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst5|inst1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst5|inst3~q\ : std_logic;
SIGNAL \insto|inst6|inst2|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst6|inst1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst6|inst3~q\ : std_logic;
SIGNAL \D[7]~input_o\ : std_logic;
SIGNAL \insto|inst7|inst1|inst1~0_combout\ : std_logic;
SIGNAL \insto|inst7|inst1|inst1~1_combout\ : std_logic;
SIGNAL \insto|inst7|inst3~q\ : std_logic;
SIGNAL \inst|inst6|inst7~0_combout\ : std_logic;
SIGNAL \inst|inst5|inst4~0_combout\ : std_logic;
SIGNAL \inst|inst4|inst2~0_combout\ : std_logic;
SIGNAL \inst|inst3|inst8~0_combout\ : std_logic;
SIGNAL \inst|inst2|inst16~0_combout\ : std_logic;
SIGNAL \inst|inst1|inst7~0_combout\ : std_logic;
SIGNAL \inst|inst|inst1~0_combout\ : std_logic;
SIGNAL \inst11|inst6|inst7~0_combout\ : std_logic;
SIGNAL \inst11|inst5|inst4~0_combout\ : std_logic;
SIGNAL \inst11|inst4|inst2~0_combout\ : std_logic;
SIGNAL \inst11|inst3|inst8~0_combout\ : std_logic;
SIGNAL \inst11|inst2|inst16~0_combout\ : std_logic;
SIGNAL \inst11|inst1|inst7~0_combout\ : std_logic;
SIGNAL \inst11|inst|inst1~0_combout\ : std_logic;
SIGNAL \inst11|inst3|ALT_INV_inst8~0_combout\ : std_logic;
SIGNAL \inst11|inst4|ALT_INV_inst2~0_combout\ : std_logic;
SIGNAL \inst|inst3|ALT_INV_inst8~0_combout\ : std_logic;
SIGNAL \inst|inst4|ALT_INV_inst2~0_combout\ : std_logic;

BEGIN

SH <= ww_SH;
ww_CLKi <= CLKi;
ww_D <= D;
ww_Selt <= Selt;
SL <= ww_SL;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\CLKi~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \CLKi~input_o\);
\inst11|inst3|ALT_INV_inst8~0_combout\ <= NOT \inst11|inst3|inst8~0_combout\;
\inst11|inst4|ALT_INV_inst2~0_combout\ <= NOT \inst11|inst4|inst2~0_combout\;
\inst|inst3|ALT_INV_inst8~0_combout\ <= NOT \inst|inst3|inst8~0_combout\;
\inst|inst4|ALT_INV_inst2~0_combout\ <= NOT \inst|inst4|inst2~0_combout\;

-- Location: IOOBUF_X26_Y29_N23
\SH[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst6|inst7~0_combout\,
	devoe => ww_devoe,
	o => \SH[6]~output_o\);

-- Location: IOOBUF_X28_Y29_N16
\SH[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst5|inst4~0_combout\,
	devoe => ww_devoe,
	o => \SH[5]~output_o\);

-- Location: IOOBUF_X23_Y29_N30
\SH[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst4|ALT_INV_inst2~0_combout\,
	devoe => ww_devoe,
	o => \SH[4]~output_o\);

-- Location: IOOBUF_X23_Y29_N23
\SH[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst3|ALT_INV_inst8~0_combout\,
	devoe => ww_devoe,
	o => \SH[3]~output_o\);

-- Location: IOOBUF_X23_Y29_N2
\SH[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst2|inst16~0_combout\,
	devoe => ww_devoe,
	o => \SH[2]~output_o\);

-- Location: IOOBUF_X21_Y29_N9
\SH[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst1|inst7~0_combout\,
	devoe => ww_devoe,
	o => \SH[1]~output_o\);

-- Location: IOOBUF_X21_Y29_N2
\SH[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst|inst|inst1~0_combout\,
	devoe => ww_devoe,
	o => \SH[0]~output_o\);

-- Location: IOOBUF_X26_Y29_N16
\SL[6]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|inst6|inst7~0_combout\,
	devoe => ww_devoe,
	o => \SL[6]~output_o\);

-- Location: IOOBUF_X28_Y29_N23
\SL[5]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|inst5|inst4~0_combout\,
	devoe => ww_devoe,
	o => \SL[5]~output_o\);

-- Location: IOOBUF_X26_Y29_N9
\SL[4]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|inst4|ALT_INV_inst2~0_combout\,
	devoe => ww_devoe,
	o => \SL[4]~output_o\);

-- Location: IOOBUF_X28_Y29_N30
\SL[3]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|inst3|ALT_INV_inst8~0_combout\,
	devoe => ww_devoe,
	o => \SL[3]~output_o\);

-- Location: IOOBUF_X26_Y29_N2
\SL[2]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|inst2|inst16~0_combout\,
	devoe => ww_devoe,
	o => \SL[2]~output_o\);

-- Location: IOOBUF_X21_Y29_N30
\SL[1]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|inst1|inst7~0_combout\,
	devoe => ww_devoe,
	o => \SL[1]~output_o\);

-- Location: IOOBUF_X21_Y29_N23
\SL[0]~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \inst11|inst|inst1~0_combout\,
	devoe => ww_devoe,
	o => \SL[0]~output_o\);

-- Location: IOIBUF_X41_Y15_N1
\CLKi~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_CLKi,
	o => \CLKi~input_o\);

-- Location: CLKCTRL_G9
\CLKi~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \CLKi~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \CLKi~inputclkctrl_outclk\);

-- Location: IOIBUF_X0_Y25_N1
\Selt[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Selt(1),
	o => \Selt[1]~input_o\);

-- Location: IOIBUF_X0_Y25_N15
\D[6]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(6),
	o => \D[6]~input_o\);

-- Location: IOIBUF_X0_Y26_N1
\Selt[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Selt(0),
	o => \Selt[0]~input_o\);

-- Location: IOIBUF_X0_Y22_N15
\D[5]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(5),
	o => \D[5]~input_o\);

-- Location: LCCOMB_X22_Y28_N10
\insto|inst5|inst2|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst5|inst2|inst1~0_combout\ = \insto|inst5|inst3~q\ $ (\Selt[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011001111001100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \insto|inst5|inst3~q\,
	datad => \Selt[0]~input_o\,
	combout => \insto|inst5|inst2|inst1~0_combout\);

-- Location: IOIBUF_X0_Y27_N22
\D[4]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(4),
	o => \D[4]~input_o\);

-- Location: IOIBUF_X0_Y23_N8
\D[3]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(3),
	o => \D[3]~input_o\);

-- Location: IOIBUF_X0_Y24_N1
\D[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(0),
	o => \D[0]~input_o\);

-- Location: LCCOMB_X22_Y28_N18
\insto|inst|inst1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst|inst1|inst1~0_combout\ = (\Selt[1]~input_o\ & ((\insto|inst|inst3~q\ $ (!\Selt[0]~input_o\)))) # (!\Selt[1]~input_o\ & (\D[0]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \D[0]~input_o\,
	datab => \Selt[1]~input_o\,
	datac => \insto|inst|inst3~q\,
	datad => \Selt[0]~input_o\,
	combout => \insto|inst|inst1|inst1~0_combout\);

-- Location: LCCOMB_X23_Y28_N26
\insto|inst4|inst3~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst4|inst3~0_combout\ = (\Selt[1]~input_o\) # (!\Selt[0]~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111100001111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Selt[0]~input_o\,
	datad => \Selt[1]~input_o\,
	combout => \insto|inst4|inst3~0_combout\);

-- Location: FF_X22_Y28_N19
\insto|inst|inst3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKi~inputclkctrl_outclk\,
	d => \insto|inst|inst1|inst1~0_combout\,
	ena => \insto|inst4|inst3~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \insto|inst|inst3~q\);

-- Location: IOIBUF_X0_Y27_N1
\D[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(1),
	o => \D[1]~input_o\);

-- Location: LCCOMB_X22_Y28_N22
\insto|inst1|inst1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst1|inst1|inst1~0_combout\ = (\Selt[1]~input_o\ & (\insto|inst1|inst3~q\ $ (((\Selt[0]~input_o\) # (\insto|inst|inst3~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000110001001000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selt[0]~input_o\,
	datab => \Selt[1]~input_o\,
	datac => \insto|inst1|inst3~q\,
	datad => \insto|inst|inst3~q\,
	combout => \insto|inst1|inst1|inst1~0_combout\);

-- Location: LCCOMB_X22_Y28_N4
\insto|inst1|inst1|inst1~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst1|inst1|inst1~1_combout\ = (\insto|inst1|inst1|inst1~0_combout\) # ((\D[1]~input_o\ & !\Selt[1]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111001011110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \D[1]~input_o\,
	datab => \Selt[1]~input_o\,
	datac => \insto|inst1|inst1|inst1~0_combout\,
	combout => \insto|inst1|inst1|inst1~1_combout\);

-- Location: FF_X22_Y28_N5
\insto|inst1|inst3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKi~inputclkctrl_outclk\,
	d => \insto|inst1|inst1|inst1~1_combout\,
	ena => \insto|inst4|inst3~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \insto|inst1|inst3~q\);

-- Location: IOIBUF_X0_Y25_N22
\D[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(2),
	o => \D[2]~input_o\);

-- Location: LCCOMB_X23_Y28_N28
\insto|inst2|inst2|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst2|inst2|inst1~0_combout\ = \insto|inst2|inst3~q\ $ (((\insto|inst1|inst3~q\ & ((\Selt[0]~input_o\) # (\insto|inst|inst3~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011110001101100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selt[0]~input_o\,
	datab => \insto|inst2|inst3~q\,
	datac => \insto|inst1|inst3~q\,
	datad => \insto|inst|inst3~q\,
	combout => \insto|inst2|inst2|inst1~0_combout\);

-- Location: LCCOMB_X22_Y28_N28
\insto|inst2|inst1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst2|inst1|inst1~0_combout\ = (\Selt[1]~input_o\ & ((\insto|inst2|inst2|inst1~0_combout\))) # (!\Selt[1]~input_o\ & (\D[2]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111000100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \D[2]~input_o\,
	datab => \Selt[1]~input_o\,
	datad => \insto|inst2|inst2|inst1~0_combout\,
	combout => \insto|inst2|inst1|inst1~0_combout\);

-- Location: FF_X22_Y28_N29
\insto|inst2|inst3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKi~inputclkctrl_outclk\,
	d => \insto|inst2|inst1|inst1~0_combout\,
	ena => \insto|inst4|inst3~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \insto|inst2|inst3~q\);

-- Location: LCCOMB_X22_Y28_N2
\insto|inst2|inst3mx1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst2|inst3mx1|inst1~0_combout\ = (\insto|inst1|inst3~q\ & ((\Selt[0]~input_o\ & ((!\insto|inst2|inst3~q\))) # (!\Selt[0]~input_o\ & (\insto|inst|inst3~q\ & \insto|inst2|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000010100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selt[0]~input_o\,
	datab => \insto|inst|inst3~q\,
	datac => \insto|inst1|inst3~q\,
	datad => \insto|inst2|inst3~q\,
	combout => \insto|inst2|inst3mx1|inst1~0_combout\);

-- Location: LCCOMB_X23_Y28_N6
\insto|inst3|inst2|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst3|inst2|inst1~0_combout\ = \Selt[0]~input_o\ $ (\insto|inst3|inst3~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111111110000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \Selt[0]~input_o\,
	datad => \insto|inst3|inst3~q\,
	combout => \insto|inst3|inst2|inst1~0_combout\);

-- Location: LCCOMB_X22_Y28_N14
\insto|inst3|inst1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst3|inst1|inst1~0_combout\ = (\Selt[1]~input_o\ & ((\insto|inst2|inst3mx1|inst1~0_combout\ $ (\insto|inst3|inst2|inst1~0_combout\)))) # (!\Selt[1]~input_o\ & (\D[3]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010111011100010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \D[3]~input_o\,
	datab => \Selt[1]~input_o\,
	datac => \insto|inst2|inst3mx1|inst1~0_combout\,
	datad => \insto|inst3|inst2|inst1~0_combout\,
	combout => \insto|inst3|inst1|inst1~0_combout\);

-- Location: FF_X22_Y28_N15
\insto|inst3|inst3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKi~inputclkctrl_outclk\,
	d => \insto|inst3|inst1|inst1~0_combout\,
	ena => \insto|inst4|inst3~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \insto|inst3|inst3~q\);

-- Location: LCCOMB_X22_Y28_N24
\insto|inst4|inst2|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst4|inst2|inst1~0_combout\ = \insto|inst4|inst3~q\ $ (((\Selt[0]~input_o\ & (!\insto|inst3|inst3~q\ & !\insto|inst2|inst3mx1|inst1~0_combout\)) # (!\Selt[0]~input_o\ & ((!\insto|inst2|inst3mx1|inst1~0_combout\) # (!\insto|inst3|inst3~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1010100110010101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst4|inst3~q\,
	datab => \Selt[0]~input_o\,
	datac => \insto|inst3|inst3~q\,
	datad => \insto|inst2|inst3mx1|inst1~0_combout\,
	combout => \insto|inst4|inst2|inst1~0_combout\);

-- Location: LCCOMB_X22_Y28_N30
\insto|inst4|inst1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst4|inst1|inst1~0_combout\ = (\Selt[1]~input_o\ & ((!\insto|inst4|inst2|inst1~0_combout\))) # (!\Selt[1]~input_o\ & (\D[4]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001011101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \D[4]~input_o\,
	datab => \Selt[1]~input_o\,
	datad => \insto|inst4|inst2|inst1~0_combout\,
	combout => \insto|inst4|inst1|inst1~0_combout\);

-- Location: FF_X22_Y28_N31
\insto|inst4|inst3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKi~inputclkctrl_outclk\,
	d => \insto|inst4|inst1|inst1~0_combout\,
	ena => \insto|inst4|inst3~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \insto|inst4|inst3~q\);

-- Location: LCCOMB_X22_Y28_N12
\insto|inst4|inst3mx1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst4|inst3mx1|inst1~0_combout\ = (\insto|inst4|inst3~q\ & ((\Selt[0]~input_o\) # ((!\insto|inst2|inst3mx1|inst1~0_combout\) # (!\insto|inst3|inst3~q\)))) # (!\insto|inst4|inst3~q\ & (((!\insto|inst3|inst3~q\ & 
-- !\insto|inst2|inst3mx1|inst1~0_combout\)) # (!\Selt[0]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1001101110111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst4|inst3~q\,
	datab => \Selt[0]~input_o\,
	datac => \insto|inst3|inst3~q\,
	datad => \insto|inst2|inst3mx1|inst1~0_combout\,
	combout => \insto|inst4|inst3mx1|inst1~0_combout\);

-- Location: LCCOMB_X22_Y28_N20
\insto|inst5|inst1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst5|inst1|inst1~0_combout\ = (\Selt[1]~input_o\ & ((\insto|inst5|inst2|inst1~0_combout\ $ (!\insto|inst4|inst3mx1|inst1~0_combout\)))) # (!\Selt[1]~input_o\ & (\D[5]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \D[5]~input_o\,
	datab => \Selt[1]~input_o\,
	datac => \insto|inst5|inst2|inst1~0_combout\,
	datad => \insto|inst4|inst3mx1|inst1~0_combout\,
	combout => \insto|inst5|inst1|inst1~0_combout\);

-- Location: FF_X22_Y28_N21
\insto|inst5|inst3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKi~inputclkctrl_outclk\,
	d => \insto|inst5|inst1|inst1~0_combout\,
	ena => \insto|inst4|inst3~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \insto|inst5|inst3~q\);

-- Location: LCCOMB_X22_Y28_N6
\insto|inst6|inst2|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst6|inst2|inst1~0_combout\ = \insto|inst6|inst3~q\ $ (((\Selt[0]~input_o\ & (!\insto|inst5|inst3~q\ & \insto|inst4|inst3mx1|inst1~0_combout\)) # (!\Selt[0]~input_o\ & ((\insto|inst4|inst3mx1|inst1~0_combout\) # (!\insto|inst5|inst3~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000011111100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selt[0]~input_o\,
	datab => \insto|inst5|inst3~q\,
	datac => \insto|inst6|inst3~q\,
	datad => \insto|inst4|inst3mx1|inst1~0_combout\,
	combout => \insto|inst6|inst2|inst1~0_combout\);

-- Location: LCCOMB_X22_Y28_N8
\insto|inst6|inst1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst6|inst1|inst1~0_combout\ = (\Selt[1]~input_o\ & ((!\insto|inst6|inst2|inst1~0_combout\))) # (!\Selt[1]~input_o\ & (\D[6]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0011000011111100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datab => \Selt[1]~input_o\,
	datac => \D[6]~input_o\,
	datad => \insto|inst6|inst2|inst1~0_combout\,
	combout => \insto|inst6|inst1|inst1~0_combout\);

-- Location: FF_X22_Y28_N9
\insto|inst6|inst3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKi~inputclkctrl_outclk\,
	d => \insto|inst6|inst1|inst1~0_combout\,
	ena => \insto|inst4|inst3~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \insto|inst6|inst3~q\);

-- Location: IOIBUF_X0_Y26_N8
\D[7]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_D(7),
	o => \D[7]~input_o\);

-- Location: LCCOMB_X22_Y28_N16
\insto|inst7|inst1|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst7|inst1|inst1~0_combout\ = (\Selt[0]~input_o\ & (!\insto|inst6|inst3~q\ & ((\insto|inst5|inst3~q\) # (!\insto|inst4|inst3mx1|inst1~0_combout\)))) # (!\Selt[0]~input_o\ & (((\insto|inst4|inst3mx1|inst1~0_combout\) # (!\insto|inst6|inst3~q\)) # 
-- (!\insto|inst5|inst3~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0101110100011111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Selt[0]~input_o\,
	datab => \insto|inst5|inst3~q\,
	datac => \insto|inst6|inst3~q\,
	datad => \insto|inst4|inst3mx1|inst1~0_combout\,
	combout => \insto|inst7|inst1|inst1~0_combout\);

-- Location: LCCOMB_X22_Y28_N26
\insto|inst7|inst1|inst1~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \insto|inst7|inst1|inst1~1_combout\ = (\Selt[1]~input_o\ & ((\insto|inst7|inst3~q\ $ (!\insto|inst7|inst1|inst1~0_combout\)))) # (!\Selt[1]~input_o\ & (\D[7]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110001000101110",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \D[7]~input_o\,
	datab => \Selt[1]~input_o\,
	datac => \insto|inst7|inst3~q\,
	datad => \insto|inst7|inst1|inst1~0_combout\,
	combout => \insto|inst7|inst1|inst1~1_combout\);

-- Location: FF_X22_Y28_N27
\insto|inst7|inst3\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \CLKi~inputclkctrl_outclk\,
	d => \insto|inst7|inst1|inst1~1_combout\,
	ena => \insto|inst4|inst3~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \insto|inst7|inst3~q\);

-- Location: LCCOMB_X23_Y28_N0
\inst|inst6|inst7~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst|inst6|inst7~0_combout\ = (\insto|inst4|inst3~q\ & (!\insto|inst7|inst3~q\ & (\insto|inst6|inst3~q\ $ (!\insto|inst5|inst3~q\)))) # (!\insto|inst4|inst3~q\ & (!\insto|inst5|inst3~q\ & (\insto|inst6|inst3~q\ $ (!\insto|inst7|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000100100100001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst6|inst3~q\,
	datab => \insto|inst5|inst3~q\,
	datac => \insto|inst7|inst3~q\,
	datad => \insto|inst4|inst3~q\,
	combout => \inst|inst6|inst7~0_combout\);

-- Location: LCCOMB_X23_Y28_N14
\inst|inst5|inst4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst|inst5|inst4~0_combout\ = (\insto|inst6|inst3~q\ & (\insto|inst4|inst3~q\ & (\insto|inst5|inst3~q\ $ (\insto|inst7|inst3~q\)))) # (!\insto|inst6|inst3~q\ & (!\insto|inst7|inst3~q\ & ((\insto|inst5|inst3~q\) # (\insto|inst4|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010110100000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst6|inst3~q\,
	datab => \insto|inst5|inst3~q\,
	datac => \insto|inst7|inst3~q\,
	datad => \insto|inst4|inst3~q\,
	combout => \inst|inst5|inst4~0_combout\);

-- Location: LCCOMB_X23_Y28_N20
\inst|inst4|inst2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst|inst4|inst2~0_combout\ = (\insto|inst5|inst3~q\ & (((\insto|inst7|inst3~q\) # (!\insto|inst4|inst3~q\)))) # (!\insto|inst5|inst3~q\ & ((\insto|inst6|inst3~q\ & (\insto|inst7|inst3~q\)) # (!\insto|inst6|inst3~q\ & ((!\insto|inst4|inst3~q\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110000011111101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst6|inst3~q\,
	datab => \insto|inst5|inst3~q\,
	datac => \insto|inst7|inst3~q\,
	datad => \insto|inst4|inst3~q\,
	combout => \inst|inst4|inst2~0_combout\);

-- Location: LCCOMB_X23_Y28_N18
\inst|inst3|inst8~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst|inst3|inst8~0_combout\ = (\insto|inst5|inst3~q\ & ((\insto|inst6|inst3~q\ & ((!\insto|inst4|inst3~q\))) # (!\insto|inst6|inst3~q\ & ((\insto|inst4|inst3~q\) # (!\insto|inst7|inst3~q\))))) # (!\insto|inst5|inst3~q\ & ((\insto|inst7|inst3~q\) # 
-- (\insto|inst6|inst3~q\ $ (!\insto|inst4|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111011010111101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst6|inst3~q\,
	datab => \insto|inst5|inst3~q\,
	datac => \insto|inst7|inst3~q\,
	datad => \insto|inst4|inst3~q\,
	combout => \inst|inst3|inst8~0_combout\);

-- Location: LCCOMB_X23_Y28_N24
\inst|inst2|inst16~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst|inst2|inst16~0_combout\ = (\insto|inst6|inst3~q\ & (\insto|inst7|inst3~q\ & ((\insto|inst5|inst3~q\) # (!\insto|inst4|inst3~q\)))) # (!\insto|inst6|inst3~q\ & (\insto|inst5|inst3~q\ & (!\insto|inst7|inst3~q\ & !\insto|inst4|inst3~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000000010100100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst6|inst3~q\,
	datab => \insto|inst5|inst3~q\,
	datac => \insto|inst7|inst3~q\,
	datad => \insto|inst4|inst3~q\,
	combout => \inst|inst2|inst16~0_combout\);

-- Location: LCCOMB_X23_Y28_N30
\inst|inst1|inst7~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst|inst1|inst7~0_combout\ = (\insto|inst5|inst3~q\ & ((\insto|inst4|inst3~q\ & ((\insto|inst7|inst3~q\))) # (!\insto|inst4|inst3~q\ & (\insto|inst6|inst3~q\)))) # (!\insto|inst5|inst3~q\ & (\insto|inst6|inst3~q\ & (\insto|inst7|inst3~q\ $ 
-- (\insto|inst4|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1100001010101000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst6|inst3~q\,
	datab => \insto|inst5|inst3~q\,
	datac => \insto|inst7|inst3~q\,
	datad => \insto|inst4|inst3~q\,
	combout => \inst|inst1|inst7~0_combout\);

-- Location: LCCOMB_X23_Y28_N16
\inst|inst|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst|inst|inst1~0_combout\ = (\insto|inst6|inst3~q\ & (!\insto|inst5|inst3~q\ & (\insto|inst7|inst3~q\ $ (!\insto|inst4|inst3~q\)))) # (!\insto|inst6|inst3~q\ & (\insto|inst4|inst3~q\ & (\insto|inst5|inst3~q\ $ (!\insto|inst7|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000100000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst6|inst3~q\,
	datab => \insto|inst5|inst3~q\,
	datac => \insto|inst7|inst3~q\,
	datad => \insto|inst4|inst3~q\,
	combout => \inst|inst|inst1~0_combout\);

-- Location: LCCOMB_X23_Y28_N22
\inst11|inst6|inst7~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst11|inst6|inst7~0_combout\ = (\insto|inst|inst3~q\ & (!\insto|inst3|inst3~q\ & (\insto|inst1|inst3~q\ $ (!\insto|inst2|inst3~q\)))) # (!\insto|inst|inst3~q\ & (!\insto|inst1|inst3~q\ & (\insto|inst2|inst3~q\ $ (!\insto|inst3|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000010010010001",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst1|inst3~q\,
	datab => \insto|inst2|inst3~q\,
	datac => \insto|inst|inst3~q\,
	datad => \insto|inst3|inst3~q\,
	combout => \inst11|inst6|inst7~0_combout\);

-- Location: LCCOMB_X23_Y28_N12
\inst11|inst5|inst4~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst11|inst5|inst4~0_combout\ = (\insto|inst1|inst3~q\ & (!\insto|inst3|inst3~q\ & ((\insto|inst|inst3~q\) # (!\insto|inst2|inst3~q\)))) # (!\insto|inst1|inst3~q\ & (\insto|inst|inst3~q\ & (\insto|inst2|inst3~q\ $ (!\insto|inst3|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0100000010110010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst1|inst3~q\,
	datab => \insto|inst2|inst3~q\,
	datac => \insto|inst|inst3~q\,
	datad => \insto|inst3|inst3~q\,
	combout => \inst11|inst5|inst4~0_combout\);

-- Location: LCCOMB_X23_Y28_N10
\inst11|inst4|inst2~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst11|inst4|inst2~0_combout\ = (\insto|inst1|inst3~q\ & (((\insto|inst3|inst3~q\) # (!\insto|inst|inst3~q\)))) # (!\insto|inst1|inst3~q\ & ((\insto|inst2|inst3~q\ & ((\insto|inst3|inst3~q\))) # (!\insto|inst2|inst3~q\ & (!\insto|inst|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1110111100001011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst1|inst3~q\,
	datab => \insto|inst2|inst3~q\,
	datac => \insto|inst|inst3~q\,
	datad => \insto|inst3|inst3~q\,
	combout => \inst11|inst4|inst2~0_combout\);

-- Location: LCCOMB_X23_Y28_N8
\inst11|inst3|inst8~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst11|inst3|inst8~0_combout\ = (\insto|inst1|inst3~q\ & ((\insto|inst2|inst3~q\ & (!\insto|inst|inst3~q\)) # (!\insto|inst2|inst3~q\ & ((\insto|inst|inst3~q\) # (!\insto|inst3|inst3~q\))))) # (!\insto|inst1|inst3~q\ & ((\insto|inst3|inst3~q\) # 
-- (\insto|inst2|inst3~q\ $ (!\insto|inst|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111110101101011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst1|inst3~q\,
	datab => \insto|inst2|inst3~q\,
	datac => \insto|inst|inst3~q\,
	datad => \insto|inst3|inst3~q\,
	combout => \inst11|inst3|inst8~0_combout\);

-- Location: LCCOMB_X23_Y28_N2
\inst11|inst2|inst16~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst11|inst2|inst16~0_combout\ = (\insto|inst2|inst3~q\ & (\insto|inst3|inst3~q\ & ((\insto|inst1|inst3~q\) # (!\insto|inst|inst3~q\)))) # (!\insto|inst2|inst3~q\ & (\insto|inst1|inst3~q\ & (!\insto|inst|inst3~q\ & !\insto|inst3|inst3~q\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1000110000000010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst1|inst3~q\,
	datab => \insto|inst2|inst3~q\,
	datac => \insto|inst|inst3~q\,
	datad => \insto|inst3|inst3~q\,
	combout => \inst11|inst2|inst16~0_combout\);

-- Location: LCCOMB_X22_Y28_N0
\inst11|inst1|inst7~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst11|inst1|inst7~0_combout\ = (\insto|inst1|inst3~q\ & ((\insto|inst|inst3~q\ & (\insto|inst3|inst3~q\)) # (!\insto|inst|inst3~q\ & ((\insto|inst2|inst3~q\))))) # (!\insto|inst1|inst3~q\ & (\insto|inst2|inst3~q\ & (\insto|inst|inst3~q\ $ 
-- (\insto|inst3|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101011010000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst|inst3~q\,
	datab => \insto|inst1|inst3~q\,
	datac => \insto|inst3|inst3~q\,
	datad => \insto|inst2|inst3~q\,
	combout => \inst11|inst1|inst7~0_combout\);

-- Location: LCCOMB_X23_Y28_N4
\inst11|inst|inst1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \inst11|inst|inst1~0_combout\ = (\insto|inst2|inst3~q\ & (!\insto|inst1|inst3~q\ & (\insto|inst|inst3~q\ $ (!\insto|inst3|inst3~q\)))) # (!\insto|inst2|inst3~q\ & (\insto|inst|inst3~q\ & (\insto|inst1|inst3~q\ $ (!\insto|inst3|inst3~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110000000010100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \insto|inst1|inst3~q\,
	datab => \insto|inst2|inst3~q\,
	datac => \insto|inst|inst3~q\,
	datad => \insto|inst3|inst3~q\,
	combout => \inst11|inst|inst1~0_combout\);

ww_SH(6) <= \SH[6]~output_o\;

ww_SH(5) <= \SH[5]~output_o\;

ww_SH(4) <= \SH[4]~output_o\;

ww_SH(3) <= \SH[3]~output_o\;

ww_SH(2) <= \SH[2]~output_o\;

ww_SH(1) <= \SH[1]~output_o\;

ww_SH(0) <= \SH[0]~output_o\;

ww_SL(6) <= \SL[6]~output_o\;

ww_SL(5) <= \SL[5]~output_o\;

ww_SL(4) <= \SL[4]~output_o\;

ww_SL(3) <= \SL[3]~output_o\;

ww_SL(2) <= \SL[2]~output_o\;

ww_SL(1) <= \SL[1]~output_o\;

ww_SL(0) <= \SL[0]~output_o\;
END structure;


