library verilog;
use verilog.vl_types.all;
entity ULA is
    port(
        Flag_N          : out    vl_logic;
        ULAOut          : out    vl_logic_vector(7 downto 0);
        selULA          : in     vl_logic_vector(2 downto 0);
        Y               : in     vl_logic_vector(7 downto 0);
        X               : in     vl_logic_vector(7 downto 0);
        Flag_Z          : out    vl_logic
    );
end ULA;
