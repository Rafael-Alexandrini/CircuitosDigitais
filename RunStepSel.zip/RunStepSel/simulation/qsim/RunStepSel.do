onerror {quit -f}
vlib work
vlog -work work RunStepSel.vo
vlog -work work RunStepSel.vt
vsim -novopt -c -t 1ps -L cycloneiv_ver -L altera_ver -L altera_mf_ver -L 220model_ver -L sgate work.RunStepSel_vlg_vec_tst
vcd file -direction RunStepSel.msim.vcd
vcd add -internal RunStepSel_vlg_vec_tst/*
vcd add -internal RunStepSel_vlg_vec_tst/i1/*
add wave /*
run -all
