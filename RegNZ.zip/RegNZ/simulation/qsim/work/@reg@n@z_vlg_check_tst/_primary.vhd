library verilog;
use verilog.vl_types.all;
entity RegNZ_vlg_check_tst is
    port(
        Nout            : in     vl_logic;
        Zout            : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end RegNZ_vlg_check_tst;
