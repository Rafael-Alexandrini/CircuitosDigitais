library verilog;
use verilog.vl_types.all;
entity contador is
    port(
        Q               : out    vl_logic;
        Clk             : in     vl_logic;
        Cin             : in     vl_logic;
        Reset           : in     vl_logic;
        Cout            : out    vl_logic
    );
end contador;
