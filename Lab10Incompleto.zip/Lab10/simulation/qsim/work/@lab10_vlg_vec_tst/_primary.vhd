library verilog;
use verilog.vl_types.all;
entity Lab10_vlg_vec_tst is
end Lab10_vlg_vec_tst;
