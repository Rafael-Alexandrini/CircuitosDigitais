library verilog;
use verilog.vl_types.all;
entity Lab10 is
    port(
        Cor             : out    vl_logic_vector(2 downto 0);
        Reset           : in     vl_logic;
        CLKi            : in     vl_logic
    );
end Lab10;
