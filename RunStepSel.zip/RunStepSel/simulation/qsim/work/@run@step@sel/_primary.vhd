library verilog;
use verilog.vl_types.all;
entity RunStepSel is
    port(
        ClkOut          : out    vl_logic;
        ClkNormal       : in     vl_logic;
        ClkManual       : in     vl_logic;
        RunDebugSel     : in     vl_logic
    );
end RunStepSel;
