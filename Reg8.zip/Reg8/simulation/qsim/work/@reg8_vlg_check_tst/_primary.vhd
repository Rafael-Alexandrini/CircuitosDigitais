library verilog;
use verilog.vl_types.all;
entity Reg8_vlg_check_tst is
    port(
        \Out\           : in     vl_logic_vector(7 downto 0);
        sampler_rx      : in     vl_logic
    );
end Reg8_vlg_check_tst;
