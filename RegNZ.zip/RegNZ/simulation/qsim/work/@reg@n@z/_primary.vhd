library verilog;
use verilog.vl_types.all;
entity RegNZ is
    port(
        Nout            : out    vl_logic;
        rst_async       : in     vl_logic;
        Clk             : in     vl_logic;
        Nin             : in     vl_logic;
        cargaNZ         : in     vl_logic;
        Zout            : out    vl_logic;
        Zin             : in     vl_logic
    );
end RegNZ;
