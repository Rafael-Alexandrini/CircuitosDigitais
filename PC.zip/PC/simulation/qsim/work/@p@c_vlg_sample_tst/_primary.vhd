library verilog;
use verilog.vl_types.all;
entity PC_vlg_sample_tst is
    port(
        cargaPC         : in     vl_logic;
        Clk             : in     vl_logic;
        incrementaPC    : in     vl_logic;
        PCin            : in     vl_logic_vector(7 downto 0);
        rst_async       : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end PC_vlg_sample_tst;
