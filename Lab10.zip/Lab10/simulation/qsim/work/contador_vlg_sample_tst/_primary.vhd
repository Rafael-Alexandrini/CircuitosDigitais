library verilog;
use verilog.vl_types.all;
entity contador_vlg_sample_tst is
    port(
        Cin             : in     vl_logic;
        Clk             : in     vl_logic;
        Reset           : in     vl_logic;
        sampler_tx      : out    vl_logic
    );
end contador_vlg_sample_tst;
