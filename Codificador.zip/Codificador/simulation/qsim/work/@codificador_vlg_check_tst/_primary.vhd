library verilog;
use verilog.vl_types.all;
entity Codificador_vlg_check_tst is
    port(
        selULA          : in     vl_logic_vector(2 downto 0);
        sampler_rx      : in     vl_logic
    );
end Codificador_vlg_check_tst;
