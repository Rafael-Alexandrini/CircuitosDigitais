library verilog;
use verilog.vl_types.all;
entity ADD is
    port(
        ADDOut          : out    vl_logic_vector(7 downto 0);
        X               : in     vl_logic_vector(7 downto 0);
        Y               : in     vl_logic_vector(7 downto 0)
    );
end ADD;
