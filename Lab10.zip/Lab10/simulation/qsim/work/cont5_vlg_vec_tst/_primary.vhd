library verilog;
use verilog.vl_types.all;
entity cont5_vlg_vec_tst is
end cont5_vlg_vec_tst;
