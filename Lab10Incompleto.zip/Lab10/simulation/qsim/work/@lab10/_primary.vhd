library verilog;
use verilog.vl_types.all;
entity Lab10 is
    port(
        g               : out    vl_logic;
        clk             : in     vl_logic;
        y               : out    vl_logic;
        r               : out    vl_logic;
        o               : out    vl_logic_vector(4 downto 0);
        S               : out    vl_logic_vector(3 downto 0)
    );
end Lab10;
