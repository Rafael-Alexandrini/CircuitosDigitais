library verilog;
use verilog.vl_types.all;
entity RunStepSel_vlg_check_tst is
    port(
        ClkOut          : in     vl_logic;
        sampler_rx      : in     vl_logic
    );
end RunStepSel_vlg_check_tst;
