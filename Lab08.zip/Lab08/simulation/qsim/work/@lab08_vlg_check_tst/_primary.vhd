library verilog;
use verilog.vl_types.all;
entity Lab08_vlg_check_tst is
    port(
        S               : in     vl_logic_vector(7 downto 0);
        SH              : in     vl_logic_vector(6 downto 0);
        SL              : in     vl_logic_vector(6 downto 0);
        sampler_rx      : in     vl_logic
    );
end Lab08_vlg_check_tst;
